<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Input Data Dosen</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="row mt-5">
            <div class="col-lg-8 col-md-10 col-sm-12 mx-auto">
                <div class="card">
                    <div class="card-header text-center bg-info text-white">
                        <h5 class="card-title"><b>Masukkan Data Dosen</b></h5>
                    </div>

                    <div class="card-body">
                        <form class="row g-3" method="POST" action="proses-dosen.php">

                        <div class="col-12 text-center fw-bold">
                            <label for="nama" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nama" name="nama">
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="nidn" class="form-label">NIDN <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nidn" name="nidn">
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="jenis_kelamin" class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                            <select id="jenis_kelamin" class="form-select" name="jenis_kelamin">
                            <option selected="" disabled>-- Pilih Jenis Kelamin --</option>
                            <option value="L">L</option>
                            <option value="P">P</option>
                            </select>
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="no_telp" class="form-label">No Telepon <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="no_telp" name="no_telp">
                        </div>

                        <div class="col-md-12 fw-bold">
                            <label for="alamat" class="form-label"> Alamat <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="alamat" name="alamat">
                        </div>


                        <div class="col-12 d-flex justify-content-center">
                            <button type="submit" name="submit" value="submit" class="btn btn-primary">Submit</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

</body>
</html>