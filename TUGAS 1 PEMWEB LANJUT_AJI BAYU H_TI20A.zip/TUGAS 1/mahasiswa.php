<?php

$dataFakultas = [
'Teknik',
'Hukum',
'FKIP',
'Ekonomi',
];

$dataProdi = [
'Teknik Informatika',
'Teknik Industri',
'Peternakan',
'Pendidikan Matematika',
'Pendidikan B.Inggris',
'Akuntansi',
'Hukum',
'Keolahragaan',
];

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Input Data Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css"
rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ"
crossorigin="anonymous">
</head>
<body>

    <div class="container">
        <div class="row mt-5">
            <div class="col-lg-8 col-md-10 col-sm-12 mx-auto">
                <div class="card">
                    <div class="card-header text-center bg-info text-white">
                        <h5 class="card-title"><b>Masukkan Data Mahasiswa</b></h5>
                    </div>

                    <div class="card-body fw-bold">
                        <form class="row g-3" method="POST" action="proses-mahasiswa.php">

                        <div class="col-12 fw-bold text-center">
                            <label for="nama" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nama" name="nama">
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="nim" class="form-label">NIM <span class="text=danger">*</span></label>
                            <input type="text" class="form-control" id="nim" name="nim">
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="semester" class="form-label">Semester <span class="text-danger">*</span></label>
                            <select id="semester" class="form-select" name="semester">
                            <option selected="" disabled>-- Pilih Semester --</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            </select>
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="fakultas" class="form-label">Fakultas <span class="text-danger">*</span></label>
                            <select id="fakultas" class="form-select" name="fakultas">
                            <option selected="" disabled>-- Pilih Fakultas --</option>
                            <?php foreach ($dataFakultas as $fakultas) { ?>
                            <option value="<?= $fakultas; ?>"><?= $fakultas; ?></option>
                            <?php } ?>
                            </select>
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="prodi" class="form-label">Prodi <span class="text-danger">*</span></label>
                            <select id="prodi" class="form-select" name="prodi">
                            <option selected="" disabled>-- Pilih Prodi --</option>
                            <?php foreach ($dataProdi as $prodi) { ?>
                            <option value="<?= $prodi; ?>"><?= $prodi; ?></option>
                            <?php } ?>
                            </select>
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="jenis_kelamin" class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                            <select id="jenis_kelamin" class="form-select" name="jenis_kelamin">
                            <option selected="" disabled>-- Pilih Jenis Kelamin --</option>
                            <option value="L">L</option>
                            <option value="P">P</option>
                            </select>
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="tempat_lahir" class="form-label">Tempat Lahir <span class="text-danger">*</span></label>
                            <input type="tempat_lahir" class="form-control" id="tempat_lahir" name="tempat_lahir">
                        </div>


                        <div class="col-md-6 fw-bold">
                            <label for="tgl_lahir" class="form-label">Tanggal Lahir <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="tgl_lahir" name="tgl_lahir"
                            placeholder="Y/m/d" >
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        
                        <div class="col-md-6 fw-bold">
                            <label for="alamat" class="form-label">Alamat<span class="text-danger">*</span></label>
                            <input type="alamat" class="form-control" id="alamat" name="alamat">
                        </div>

                        <div class="col-md-6 fw-bold">
                            <label for="dsn_wali" class="form-label">Dosen Wali <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="dsn_wali" name="dsn_wali">
                        </div>

                        <div class="col-12 d-flex justify-content-center">
                            <button type="submit" name="submit" value="submit" class="btn btn-primary">Submit</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
crossorigin="anonymous"></script>

</body>
</html>
